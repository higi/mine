OhGodATool allows you to edit PowerPlay in the VBIOS, or in the kernel's pp_table. You can edit clock, memory, or voltage tables.

## Please understand that if you use this tool, you do so at your own risk, voiding your warranty on your card. We will not assist you in any way.

The various branches provide other tools, including:

- OhGodADecode decodes an entire timing 'strap'. A strap is the format of timing values, stored in hexadecimal in AMD's VBIOS.
- OhGodACsumFixer corrects the checksum - this is changed whenever you edit the straps. It does not fix the signing value. 
- OhGodAnOffset allows undervolting on Linux, by allowing you to tell the regulator what to do. It is a paid-for tool, 1.5 BTC - if you are interested, please contact us via:
	- Mail: ohgodagirl@gmail.com
	- BitcoinTalk: ohgodagirl or wolf0
	- IRC: OhGodAGirl or OhGodAPet on Freenode
			
		Payment should be sent to 1buttzjpRmejg9iaZam8S9ugkkcP5dgbC.
		
		
